import { extendTheme } from "@chakra-ui/react";
// 2. Add your color mode config
const config = {
  initialColorMode: "light",
  useSystemColorMode: false,
};

const fontsize = {
  full: "100px",
};

// 3. extend the theme
const theme = extendTheme({
  config,
  fontsize,
});
export default theme;
